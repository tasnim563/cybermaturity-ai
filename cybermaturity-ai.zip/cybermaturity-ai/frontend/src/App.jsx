import { useEffect, useMemo, useState } from "react";
import { getControls, assess, recommend } from "./api";
import Radar from "./Radar.jsx";

const LEVELS = ["0 · Inexistant", "1 · Initial", "2 · Défini", "3 · Géré", "4 · Optimisé"];
const color = (v) => (v < 1.5 ? "var(--rk)" : v < 2.5 ? "var(--wn)" : v < 3.5 ? "var(--ac)" : "var(--ok)");

export default function App() {
  const [controls, setControls] = useState([]);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [recs, setRecs] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => { getControls().then(setControls).catch((e) => setError(e.message)); }, []);

  const groups = useMemo(() => {
    const g = {};
    controls.forEach((c) => (g[c.function_name] ||= []).push(c));
    return g;
  }, [controls]);
  const done = Object.keys(answers).length;

  async function submit() {
    setBusy(true); setError(""); setRecs(null);
    try {
      setResult(await assess(answers));
      window.scrollTo(0, 0);
      setRecs(await recommend(answers));
    } catch (e) { setError(e.message); }
    setBusy(false);
  }

  const demo = () => {
    const a = {};
    controls.forEach((c) => (a[c.id] = Math.floor(Math.random() * 5)));
    setAnswers(a);
  };

  if (result)
    return (
      <main>
        <h1>Résultats de l'évaluation</h1>
        <div className="card res">
          <div>
            <div className="glob">{result.global.toFixed(1)}<small> / 4</small></div>
            <span className="pill" style={{ background: color(result.global) }}>Maturité {result.level.toLowerCase()}</span>
            <p className="mu">{result.gaps.length} écart(s) identifié(s), classés par impact.</p>
          </div>
          <Radar functions={result.functions} />
        </div>
        <div className="card">
          <h2>Score par fonction</h2>
          {Object.entries(result.functions).map(([k, f]) => (
            <div className="row" key={k}>
              <span>{f.name}</span>
              <div className="track"><i style={{ width: `${(f.score / 4) * 100}%`, background: color(f.score) }} /></div>
              <b>{f.score.toFixed(1)}</b>
            </div>
          ))}
        </div>
        <div className="card">
          <h2>Recommandations de remédiation (RAG)</h2>
          {!recs && !error && <p className="mu">Génération des recommandations à partir de la base documentaire…</p>}
          {recs?.map((r) => (
            <article key={r.id} className={`rec ${r.priority}`}>
              <b>{r.function} · {r.id}</b>
              <div className="mu">Niveau {r.score}/4 · priorité {r.priority}</div>
              <p className="pre">{r.text}</p>
              <div className="mu"><i>Sources : {r.sources.join(", ")}</i></div>
            </article>
          ))}
        </div>
        {error && <p className="err">{error}</p>}
        <button className="ghost" onClick={() => setResult(null)}>Modifier l'évaluation</button>
      </main>
    );

  return (
    <main>
      <h1>CyberMaturity AI</h1>
      <p className="mu">Auto-évaluation de la maturité cybersécurité basée sur NIST CSF 2.0 et ISO 27001.</p>
      {error && <p className="err">{error}</p>}
      {Object.entries(groups).map(([name, cs]) => (
        <section className="card" key={name}>
          <h2>{name}</h2>
          {cs.map((c) => (
            <div className="q" key={c.id}>
              <b>{c.text}</b> <small className="mu">{c.id} · ISO {c.iso}</small>
              <div className="sc" role="radiogroup" aria-label={c.id}>
                {LEVELS.map((l, i) => (
                  <label key={i} className={answers[c.id] === i ? "on" : ""}>
                    <input type="radio" name={c.id} checked={answers[c.id] === i}
                      onChange={() => setAnswers({ ...answers, [c.id]: i })} />
                    {l}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </section>
      ))}
      <div className="bar">
        <span>{done} / {controls.length} contrôles</span>
        <div>
          <button className="ghost" onClick={demo}>Exemple</button>{" "}
          <button className="cta" disabled={busy || !controls.length || done < controls.length} onClick={submit}>
            {busy ? "Analyse…" : "Analyser"}
          </button>
        </div>
      </div>
    </main>
  );
}
