export default function Radar({ functions }) {
  const list = Object.values(functions), n = list.length, R = 110, cx = 170, cy = 150;
  const pt = (i, v) => {
    const a = -Math.PI / 2 + (i * 2 * Math.PI) / n;
    return [cx + ((R * v) / 4) * Math.cos(a), cy + ((R * v) / 4) * Math.sin(a)];
  };
  return (
    <svg viewBox="0 0 340 300" role="img" aria-label="Radar de maturité">
      {[1, 2, 3, 4].map((l) => (
        <polygon key={l} points={list.map((_, i) => pt(i, l).join(",")).join(" ")} fill="none" stroke="var(--ln)" />
      ))}
      {list.map((f, i) => (
        <g key={f.name}>
          <line x1={cx} y1={cy} x2={pt(i, 4)[0]} y2={pt(i, 4)[1]} stroke="var(--ln)" />
          <text x={pt(i, 4.7)[0]} y={pt(i, 4.7)[1]} textAnchor="middle" dominantBaseline="middle">{f.name}</text>
        </g>
      ))}
      <polygon points={list.map((f, i) => pt(i, f.score).join(",")).join(" ")}
        fill="var(--ac)" fillOpacity=".22" stroke="var(--ac)" strokeWidth="2" />
    </svg>
  );
}
