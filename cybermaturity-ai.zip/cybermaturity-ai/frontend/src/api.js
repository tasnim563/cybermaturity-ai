const j = async (r) => {
  if (!r.ok) throw new Error(`Erreur ${r.status}`);
  return r.json();
};
const post = (u, body) =>
  fetch(u, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(j);

export const getControls = () => fetch("/api/controls").then(j);
export const assess = (answers) => post("/api/assess", { answers });
export const recommend = (answers) => post("/api/recommendations", { answers });
