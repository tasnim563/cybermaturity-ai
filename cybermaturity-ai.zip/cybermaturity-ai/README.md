# CyberMaturity AI

Plateforme d'auto-évaluation de la maturité cybersécurité (NIST CSF 2.0 / ISO 27001).
Stack : React (Vite) · FastAPI · LangChain · FAISS · Docker.

## Lancer
```bash
docker compose up --build      # app : http://localhost:3000 · API : http://localhost:8000/docs
```
Sans clé, les recommandations = action de base + passages retrouvés par FAISS.
Avec `OPENAI_API_KEY=sk-... docker compose up`, un LLM rédige un plan d'actions à partir des passages.

## Dev local
```bash
cd backend && pip install -r requirements.txt && INDEX_DIR=./faiss_index uvicorn app.main:app --reload
cd frontend && npm install && npm run dev
```

## Architecture
- `backend/app/controls.py` : 18 contrôles (fonction, ISO, poids)
- `backend/app/scoring.py` : moteur de scoring pondéré, niveaux et écarts priorisés
- `backend/app/rag.py` : indexation FAISS des documents `data/kb/*.md`, recherche et génération
- `backend/app/main.py` : API (`/api/controls`, `/api/assess`, `/api/recommendations`)
- `frontend/` : formulaire, radar, barres de score, recommandations

Ajouter des documents : déposer des `.md` dans `backend/app/data/kb/`, supprimer le volume `faiss_index`, relancer.
