from .controls import CONTROLS, FUNCTIONS, BY_ID

LEVELS = [(1.5, "Initial"), (2.5, "Défini"), (3.5, "Géré"), (4.01, "Optimisé")]

def level(score: float) -> str:
    return next(name for limit, name in LEVELS if score < limit)

def compute(answers: dict[str, int]) -> dict:
    """Score pondéré par fonction (0-4), score global et écarts priorisés."""
    per_fn, gaps = {}, []
    for code, name in FUNCTIONS.items():
        cs = [c for c in CONTROLS if c["function"] == code and c["id"] in answers]
        if not cs:
            continue
        tw = sum(c["weight"] for c in cs)
        s = sum(answers[c["id"]] * c["weight"] for c in cs) / tw
        per_fn[code] = {"name": name, "score": round(s, 2), "level": level(s)}
    for cid, v in answers.items():
        c = BY_ID[cid]
        if v <= 2:
            gaps.append({"id": cid, "function": c["function_name"], "text": c["text"],
                         "iso": c["iso"], "score": v, "gap": (4 - v) * c["weight"],
                         "priority": "haute" if v <= 1 and c["weight"] >= 2 else "moyenne"})
    gaps.sort(key=lambda g: g["gap"], reverse=True)
    g = sum(f["score"] for f in per_fn.values()) / max(len(per_fn), 1)
    return {"global": round(g, 2), "level": level(g), "functions": per_fn, "gaps": gaps}
