# NIST CSF 2.0
Le CSF 2.0 organise la cybersécurité en six fonctions : Gouverner (GV), Identifier (ID), Protéger (PR), Détecter (DE), Répondre (RS) et Récupérer (RC). La fonction Gouverner, nouvelle en 2.0, couvre la stratégie, les rôles, la politique et la gestion des risques.
## Gouverner
Une politique de sécurité doit être approuvée par la direction, communiquée et revue. Les rôles (RSSI, propriétaires de risques) sont attribués. Le registre des risques est révisé régulièrement, avec une méthode reconnue comme EBIOS RM ou ISO 27005.
## Identifier
L'inventaire des actifs avec propriétaire et criticité est le socle. Les vulnérabilités sont scannées chaque mois et corrigées selon leur criticité (CVSS, exploitation active). Les fournisseurs critiques sont évalués par questionnaire et clauses contractuelles.
## Protéger
Le MFA est exigé pour les accès distants et administrateurs. Le chiffrement TLS 1.2+ et le chiffrement des disques protègent les données. La sensibilisation inclut des simulations de phishing et un suivi des taux de clic.
## Détecter
Un SIEM centralise les journaux et un EDR couvre les postes et serveurs. Les alertes suivent un playbook de qualification avec niveaux de criticité. Un pentest annuel valide l'efficacité des mesures.
## Répondre et Récupérer
Le plan de réponse à incident définit rôles, canaux de communication et procédures. Un retour d'expérience suit chaque incident. Le PRA fixe RTO et RPO et est testé chaque année. Les sauvegardes suivent la règle 3-2-1 avec une copie immuable.
