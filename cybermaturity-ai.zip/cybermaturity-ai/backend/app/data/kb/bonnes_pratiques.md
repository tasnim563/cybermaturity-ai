# Bonnes pratiques de remédiation
## Priorisation
Traiter d'abord les contrôles de poids élevé avec un niveau 0 ou 1 : MFA, sauvegardes isolées, gestion des vulnérabilités, plan de réponse aux incidents. Viser des gains rapides sous 30 jours, puis un plan à 90 jours et à 12 mois.
## Feuille de route type
30 jours : activer le MFA sur les comptes à privilèges, vérifier une sauvegarde hors ligne, nommer un responsable sécurité. 90 jours : inventaire des actifs, scans de vulnérabilités récurrents, plan de réponse aux incidents testé par un exercice sur table. 12 mois : SIEM et EDR, PRA testé, audit ou pentest, revue de direction.
## Indicateurs de suivi
Taux de couverture MFA, délai moyen de correction des vulnérabilités critiques, taux de clic phishing, taux de réussite des tests de restauration, temps moyen de détection et de réponse.
