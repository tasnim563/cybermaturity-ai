"""RAG : LangChain + FAISS sur la base documentaire (app/data/kb/*.md)."""
import os
from pathlib import Path
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter

KB = Path(__file__).parent / "data" / "kb"
INDEX = Path(os.getenv("INDEX_DIR", "/tmp/faiss_index"))
_store = None

def store() -> FAISS:
    global _store
    if _store:
        return _store
    emb = HuggingFaceEmbeddings(model_name=os.getenv(
        "EMBED_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"))
    if INDEX.exists():
        _store = FAISS.load_local(str(INDEX), emb, allow_dangerous_deserialization=True)
    else:
        docs = DirectoryLoader(str(KB), glob="*.md", loader_cls=TextLoader,
                               loader_kwargs={"encoding": "utf-8"}).load()
        chunks = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=80).split_documents(docs)
        _store = FAISS.from_documents(chunks, emb)
        _store.save_local(str(INDEX))
    return _store

def recommend(control: dict, score: int) -> dict:
    docs = store().similarity_search(f"{control['id']} {control['text']}", k=3)
    ctx = "\n---\n".join(d.page_content for d in docs)
    sources = sorted({Path(d.metadata["source"]).name for d in docs})
    if os.getenv("OPENAI_API_KEY"):
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI(model=os.getenv("LLM_MODEL", "gpt-4o-mini"), temperature=0.2)
        prompt = (f"Tu es consultant cybersécurité. Contrôle {control['id']} (ISO 27001 {control['iso']}) : "
                  f"« {control['text']} » Niveau actuel : {score}/4.\n"
                  f"Contexte documentaire :\n{ctx}\n\n"
                  "Rédige en français 3 à 5 actions de remédiation concrètes et ordonnées, "
                  "en t'appuyant uniquement sur le contexte.")
        text = llm.invoke(prompt).content
    else:  # mode sans LLM : recommandation de base + passages retrouvés
        text = f"{control['reco']}\n\nPassages pertinents :\n{ctx}"
    return {"id": control["id"], "text": text, "sources": sources}
