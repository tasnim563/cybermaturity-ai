FUNCTIONS = {"GV": "Gouverner", "ID": "Identifier", "PR": "Protéger",
             "DE": "Détecter", "RS": "Répondre", "RC": "Récupérer"}

# (id, texte, ISO 27001, poids 1-3, recommandation de base)
_RAW = [
 ("GV.PO","Une politique de sécurité approuvée par la direction existe et est revue chaque année.","A.5.1",3,"Rédiger une politique de sécurité validée par la direction, la diffuser et la réviser annuellement."),
 ("GV.RR","Les rôles et responsabilités cyber (RSSI, propriétaires de risques) sont formalisés.","A.5.2",2,"Nommer un RSSI, formaliser une matrice RACI et un comité de pilotage sécurité."),
 ("GV.RM","Une gestion des risques cyber documentée est menée régulièrement.","6.1.2",3,"Mettre en place un registre des risques (EBIOS RM ou ISO 27005) avec revue trimestrielle."),
 ("ID.AM","L'inventaire des actifs (matériel, logiciels, données) est complet et à jour.","A.5.9",3,"Construire un inventaire automatisé avec propriétaire et criticité pour chaque actif."),
 ("ID.RA","Les vulnérabilités sont recherchées et priorisées de façon récurrente.","A.8.8",3,"Planifier des scans mensuels et un processus de correctifs priorisé par criticité."),
 ("ID.SC","Les fournisseurs critiques sont évalués sur la sécurité.","A.5.19",2,"Ajouter des clauses sécurité aux contrats et évaluer les fournisseurs critiques chaque année."),
 ("PR.AA","L'authentification multifacteur protège les accès sensibles et à distance.","A.5.15",3,"Déployer le MFA sur les accès distants, administrateurs et messagerie ; appliquer le moindre privilège."),
 ("PR.DS","Les données sensibles sont chiffrées au repos et en transit.","A.8.24",3,"Chiffrer disques, sauvegardes et flux (TLS 1.2+) avec une gestion centralisée des clés."),
 ("PR.AT","Les collaborateurs sont sensibilisés (phishing, bonnes pratiques) régulièrement.","A.6.3",2,"Lancer un programme annuel de sensibilisation avec simulations de phishing."),
 ("DE.CM","Une supervision continue (EDR, SIEM, journaux) détecte les activités anormales.","A.8.16",3,"Centraliser les journaux dans un SIEM, déployer un EDR et définir des cas d'usage de détection."),
 ("DE.AE","Les alertes sont qualifiées selon un processus défini.","A.5.25",2,"Définir des seuils de criticité, un playbook de qualification et une astreinte."),
 ("DE.IM","Des tests (audit, pentest) évaluent régulièrement l'efficacité des mesures.","A.8.34",2,"Réaliser un pentest annuel et suivre les écarts dans un plan d'action daté."),
 ("RS.MA","Un plan de réponse aux incidents est documenté et connu.","A.5.26",3,"Rédiger un plan de réponse aux incidents avec rôles, canaux et procédures par type d'incident."),
 ("RS.CO","La communication de crise (interne, autorités, clients) est préparée.","A.5.24",2,"Préparer des modèles de communication de crise et la liste des obligations de notification."),
 ("RS.AN","Chaque incident fait l'objet d'une analyse et d'un retour d'expérience.","A.5.27",1,"Systématiser un retour d'expérience après chaque incident et alimenter le plan d'amélioration."),
 ("RC.RP","Un plan de reprise d'activité (PRA) existe et est testé.","A.5.30",3,"Définir RTO/RPO par service critique, rédiger un PRA et le tester au moins une fois par an."),
 ("RC.BK","Des sauvegardes isolées et testées permettent la restauration.","A.8.13",3,"Appliquer la règle 3-2-1 avec une copie hors ligne ou immuable et tester la restauration chaque trimestre."),
 ("RC.CO","Les parties prenantes sont informées pendant la reprise.","A.5.29",1,"Définir un circuit d'information des parties prenantes pendant la reprise."),
]
CONTROLS = [{"id": i, "function": i[:2], "function_name": FUNCTIONS[i[:2]], "text": t,
             "iso": iso, "weight": w, "reco": r} for i, t, iso, w, r in _RAW]
BY_ID = {c["id"]: c for c in CONTROLS}
