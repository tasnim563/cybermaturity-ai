from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .controls import CONTROLS, BY_ID
from .scoring import compute
from . import rag

app = FastAPI(title="CyberMaturity AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class Assessment(BaseModel):
    answers: dict[str, int] = Field(..., description="id du contrôle -> niveau 0..4")

def check(a: Assessment):
    for k, v in a.answers.items():
        if k not in BY_ID or not 0 <= v <= 4:
            raise HTTPException(422, f"Réponse invalide : {k}={v}")

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/controls")
def controls():
    return [{k: c[k] for k in ("id", "function", "function_name", "text", "iso")} for c in CONTROLS]

@app.post("/api/assess")
def assess(a: Assessment):
    check(a)
    return compute(a.answers)

@app.post("/api/recommendations")
def recommendations(a: Assessment, top: int = 5):
    check(a)
    gaps = compute(a.answers)["gaps"][:top]
    return [{**rag.recommend(BY_ID[g["id"]], g["score"]), "priority": g["priority"],
             "function": g["function"], "score": g["score"]} for g in gaps]
